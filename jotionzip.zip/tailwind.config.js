export default {
  darkMode: "class",
  // ... other config
};