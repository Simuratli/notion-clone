export default {
  providers: [
    {
      domain: "https://secure-silkworm-74.clerk.accounts.dev",
      applicationID: "convex",
    },
  ],
};
